# CS2 Roblox AI Skills

**Free instructions and original visual reference diagrams for building a Counter-Strike 2-inspired tactical FPS in Roblox Studio using AI coding agents.**

> Unofficial fan-created educational resource. Not affiliated with or endorsed by Valve or Roblox. No proprietary CS2 models, textures, audio, maps, or other assets are included. Build original or properly licensed assets.

## What's included

Modular Markdown specifications for weapons, viewmodels, animations, knife inspection, 3D models, case opening, cosmetic inventory, UI, tactical rounds, maps, bots, sound, networking, security, performance, and testing. Original SVG reference diagrams are in `CS2-VISUAL-REFERENCES/`. These are **instructions and diagrams, not a finished Roblox game**.

## Quick start

1. Download the repository ZIP from GitHub (`Code` → `Download ZIP`) or clone it.
2. Put the files into your Roblox project workspace where your AI coding assistant can read them.
3. Ask the agent to read `CS2-START-HERE.md`, `CS2-PROJECT-RULES.md`, and `CS2-PROJECT-STATE.md`.
4. Have the agent inspect the existing game before making edits, then implement one feature at a time.
5. Review and playtest every change in Roblox Studio.

### Starter prompt

```text
Read CS2-START-HERE.md, CS2-PROJECT-RULES.md and CS2-PROJECT-STATE.md. Inspect the current Roblox Studio project. Do not edit anything yet. Summarize what already exists, identify the next smallest testable task, and list the specific skill files needed.
```

## Scope and safety

Case-opening mechanics should use non-purchasable demo currency or earned in-game tokens; show odds and never promise real-world value. Do not implement real-money gambling or cash-out. Use server-authoritative rewards and persistence.

## License

The original instructions and original diagrams in this repository are provided under the MIT License (see `LICENSE`). Third-party trademarks and assets are excluded.
