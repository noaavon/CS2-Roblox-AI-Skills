# Case Opening — full subsystem
Scope: cosmetic cases with earned, non-purchasable gameplay currency only. No real-money purchases, cashout, trading for value, or paid random rewards in the initial release. Display rarity odds clearly.

## Architecture
CaseCatalog (immutable server data), RewardPool (weights), CaseService (server), InventoryService (server), CaseController (client), CaseRevealUI (client), RewardShowcase (client), CurrencyService (server). Server owns balances, rolls, and inventory. Client animation never determines prize.

## Sequence
1. UI selects case and shows full contents, exact probabilities, and cost. 2. Client requests open with caseId and unique requestId. 3. Server validates player, case, cost, cooldown, requestId idempotency, capacity and session state. 4. Atomic purchase + server RNG weighted selection + inventory grant; avoid partial debit without reward. 5. Server sends rewardId and revealSeed or reel descriptor. 6. Client animates a predetermined result, not a fake roll. 7. Persist transaction and provide retry-safe receipt. 8. User can equip or close.

## Reel animation
Opening intro 0.35s, reel accelerate 0.6s, constant motion 2.0s, ease-out 2.2s, centered final item, reveal 0.6s. All timings configurable; use TweenService easing with no frame-rate-dependent loops. Show rarity glow, confetti only for rare tiers, original SFX, optional reduced-motion mode and skip after server award. Stop exactly on server-selected item; adjacent reel items are decorative. Cancel/respawn/rejoin must never reroll.

## 3D case model
Original low-poly/high-quality hard case, lid hinges, latches, inset emblem, PBR metal/plastic, staged camera, key rotation (purely cosmetic), lid opening, volumetric-like lighting without excessive particles. Preview in ViewportFrame with a dedicated WorldModel; do not render dozens of live MeshParts every frame.

## Probabilities example (design defaults, not CS2 claims)
Common 70%, Uncommon 22%, Rare 6%, Epic 1.8%, Legendary 0.2%. Use integer weights totaling 10000: 7000/2200/600/180/20. Server samples uniform integer 1..10000 and cumulative ranges. Publish odds in UI. No pity system unless explicitly specified and disclosed.

## Tests
10k deterministic simulated opens for approximate distribution (tolerance statistical); duplicate request replay; 2 concurrent opens; insufficient funds; disconnect during reveal; DataStore failure; invalid caseId; forged rewardId; cancellation; reduced-motion mode; 16:9 and 4:3 UI. No external monetization by default.
