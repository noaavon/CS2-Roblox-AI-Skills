# Audio and visual effects
Original/licensed recordings only. Layered weapon fire: transient, mechanical, low-frequency body, outdoor tail, indoor tail. Animation markers drive reload, knife whoosh, case latch, key insert, reward reveal. Use spatial audio for world and local audio for viewmodel. Distances, rolloff and reverb must be configurable.

FX: short muzzle flash, pooled tracer, impact material response, shell eject with capped lifetime, recoil camera impulse, subtle screen feedback, rarity glow, case sparks and highlight. Optimize for mid-range GPUs, cap particle counts and remove on state exit. Include mute sliders, volume groups, photosensitivity and reduced-motion settings.
