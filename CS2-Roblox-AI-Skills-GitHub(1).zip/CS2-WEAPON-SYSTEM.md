# Weapon System Skill
Scope: one requested weapon at a time. Read core rules and project state first.

## Design
- Separate WeaponConfig, WeaponController (client), WeaponService (server), ViewmodelController, WeaponFX and input mapping.
- Data-driven settings: magazine, reserve ammo, rate of fire, equip/reload times, damage falloff, recoil pattern, spread, movement inaccuracy, penetration rules.
- Viewmodel: Roblox-style rigged arms, consistent hand grips, camera-local pivot, ADS only if requested, subtle sway and bob, no clipping through camera.
- Fire: client predicts feedback; server validates ammo, fire rate, origin/direction plausibility and raycast damage. Never trust client hit reports alone.
- Animate reload with explicit magazine detach/attach events and sound markers. Reload cannot duplicate ammo.
- Effects: muzzle flash, tracers, shell casing, impact particles, distance-aware audio; throttle and pool when practical.
- Test: idle, single fire, hold fire, empty mag, reload, weapon swap mid-reload, death, respawn, high latency, two-player replication.
- Provide clear implementation status and only verified results.
