# UI Design Skill
Scope: one UI panel or HUD subsystem at a time.
- Use original styling inspired by modern tactical shooters, not copied Valve branding.
- Use ScreenGui, responsive constraints, safe-area considerations, UIScale and consistent tokens.
- Document HUD elements with normalized positions, typography, spacing, states and visibility conditions.
- HUD: team score, timer, health, armor, ammo, weapon slots, crosshair, kill feed, radar, money.
- Buy menu: item prices and eligibility validated server-side.
- Spectator: target name, team, weapon, ammo, health and cycling controls; do not leak hidden enemy information.
- Test at 1920x1080, 1600x900, 1280x720 and 4:3; verify no overlap.
- Keep UI update event-driven rather than rebuilding every frame.
