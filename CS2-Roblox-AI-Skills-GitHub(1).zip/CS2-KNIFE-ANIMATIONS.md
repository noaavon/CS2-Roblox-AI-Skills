# Knife animations — original choreography
State machine: equip, idle A/B, light slash A/B, heavy slash, inspect 1/2/rare, sprint, holster, interrupted. For butterfly-style knife, hinge-driven handle rotations with hand constraints; no teleporting parts. Use Roblox-styled R15 arms on camera-local viewmodel; animation tracks for arms, Motor6D or bone rig for knife, and animation markers for whoosh/contact.

Example inspect: 0–0.18 anticipation, 0.18–0.55 handle flip, 0.55–0.9 blade settle, 0.9–1.4 flourish, 1.4–1.8 return idle. These are original design timings, not measured CS2 data. Blend all states; cancel on swap/death; first-person and third-person animations separate. No camera roll that causes nausea; reduced-motion option.

Verify hand grip, hinge motion, no clipping at multiple FOVs, 30/60/144 FPS, transition to attack from inspect, network spectators see plausible third-person pose.
