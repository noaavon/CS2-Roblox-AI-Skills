# PROJECT-CS2 — Core Rules
Goal: original Roblox tactical FPS inspired by Counter-Strike 2. Do not extract proprietary Valve assets or reuse unlicensed meshes, textures, sounds, logos, or maps.

## Mandatory workflow
1. Read this file, then ONLY the skill relevant to the current task.
2. Inspect existing project structure and affected scripts before changing anything. Never assume files or features exist.
3. One task = one subsystem. Do not add maps, menus, weapons, vehicles or unrelated features unless explicitly requested.
4. Prefer reusing existing modules and assets. Avoid duplicating systems.
5. Before editing, give a compact plan (max 6 lines), affected paths, and acceptance criteria.
6. Implement, run available tests, inspect errors, fix regressions.
7. Final response: changed paths, what works, test result, remaining blockers. Max 180 words unless asked.
8. Never claim video was watched, assets imported, Studio accessed, or tests run unless actually performed.
9. When evidence is missing, mark UNVERIFIED; ask for screenshots, clips, or demo data instead of fabricating measurements.
10. Keep a concise CS2-PROJECT-STATE.md with implemented systems, paths, known issues, next task. Update it after each task; read it instead of rereading chat history.

## Engineering
- Luau strict where practical; modular client/server architecture.
- Server authoritative for damage, ammo, purchases, round results; validate RemoteEvents, cooldowns, ranges and team rules.
- Cosmetic recoil/viewmodel/audio are client-side; replicate necessary third-person effects.
- Avoid heavy per-frame allocations, excessive Parts, unbounded effects, and copied scripts.
- Aim for desktop keyboard/mouse first; test two-player replication and exploit-resistant actions.
- No unsupported claim of pixel-perfect or engine-identical reproduction.

## Token discipline
- Do not dump whole files or logs unless requested.
- Read only changed files and direct dependencies; summarize discoveries in CS2-PROJECT-STATE.md.
- Do not repeat instructions or prior analysis; reference skill filenames.
- If blocked, stop and state exact missing input.
