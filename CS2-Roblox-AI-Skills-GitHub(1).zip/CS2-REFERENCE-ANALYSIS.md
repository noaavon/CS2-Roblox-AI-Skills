# Reference Analysis Skill
Use when analyzing CS2 videos, demo POV, screenshots, HUD, or gameplay. Never claim frame-by-frame analysis without accessible footage.

## Evidence procedure
1. Record source URL, date, resolution, frame rate, camera mode (POV, observer, third-person), map, weapon and build date if known.
2. For each feature, capture timestamps and representative frames: idle, draw, fire, recoil recovery, reload, inspect, move, jump, crouch, death, spectator, buy, round transitions.
3. Separate OBSERVED, ESTIMATED and UNKNOWN. Never turn an estimate into a measured fact.
4. Create a compact reference table: timestamp | feature | observation | approximate duration | Roblox implementation | confidence.
5. Record screen-space positions normalized 0..1, camera FOV if known, animation phase timings, sound event timing and environmental audio differences.
6. Compare at least two clips when possible. Prefer unedited POV with HUD for controls, spectator/demo for third-person poses and map flow.
7. Deliver a short spec and task-ready acceptance tests, not a long narrative.

## Domains
- UI: radar, timer, team score, health/armor, ammo, kill feed, buy panel, spectator HUD.
- Weapons: silhouette, grip, camera-relative offsets, shell ejection, muzzle flash, reload sequence, sound layers, recoil and spread.
- Movement: acceleration, friction, jump arc, crouch, weapon sway, landing feedback.
- World: scale, routes, collision, materials, lighting, occlusion and cover.
- Round: freeze time, economy, plant/defuse, spectating and win conditions.

## Licensing
Use reference media for observation only. Create original or licensed game assets.
