# Maps and Assets Skill
Scope: original geometry and properly licensed assets.
- Start with graybox routes and bombsites before art pass. Use reference for gameplay principles, not one-to-one copyrighted map reproduction.
- Maintain scale, sightlines, cover, jump spots, collision and spawn fairness.
- Asset registry: asset name | source URL | author | license | permission | imported ID | optimization notes.
- Use Roblox Creator Store/Toolbox only after verifying creator, permissions, script contents and dependencies. Do not trust embedded scripts.
- For weapons use Blender or original MeshParts, sensible triangle counts, LODs, textures and materials.
- Sound: record/create original or license suitable sounds; avoid ripping CS2 audio.
- Lighting: readable silhouettes, balanced exposure, performant shadows, consistent PBR material response.
- Test collision, FPS, network ownership, streaming, spawn safety and visibility.
