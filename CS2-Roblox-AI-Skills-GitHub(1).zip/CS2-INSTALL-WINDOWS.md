# Windows installation / download
1. Download PROJECT-CS2-SKILLS-V2.zip from the chat link.
2. In Windows Explorer right-click the ZIP > Extract All.
3. Place extracted PROJECT-CS2-V2 folder next to your Roblox project source folder (for example `C:\RobloxProjects\PROJECT-CS2-V2`).
4. Open the project workspace in Codex / OpenCode / Astra agent that has filesystem access. A Roblox Studio-only assistant cannot automatically read files outside its sandbox.
5. Paste: `Read PROJECT-CS2-V2/CS2-PROJECT-RULES.md and PROJECT-CS2-V2/CS2-PROJECT-STATE.md. Inspect the project. Do not modify anything. Report current state.`
6. For each mechanic paste the relevant section from CS2-PROMPT-LIBRARY.md. If agent lacks file access, paste the necessary Markdown contents manually.
7. For Roblox Studio changes use your existing Studio bridge/MCP integration if configured; otherwise export scripts/models through the supported workflow and import manually.
8. Markdown skill pack is not an RBXL place file, and does not contain finished 3D meshes, animations, sounds or Roblox place assets. The agent creates those later when its tools support them.
