# Ready-to-run staged prompts
## 0 Audit
Read CS2-PROJECT-RULES.md, CS2-PROJECT-STATE.md, and only relevant files. Inspect actual Studio/source tree, report verified systems, missing assets and blockers. No changes.

## 1 Knife prototype
Read CS2-ANIMATION.md, CS2-3D-MODELS.md, CS2-KNIFE-ANIMATIONS.md. Implement ONLY an original butterfly-style knife with Roblox R15 first-person arms, working hinge pivots, equip/idle/inspect animations and correct interruption. Inspect files first, show plan, implement, test and update state. No new menu or gun.

## 2 Case backend
Read CS2-CASE-OPENING.md, CS2-INVENTORY-SKINS.md, CS2-ECONOMY-SECURITY.md. Implement ONLY server catalog, integer-weight roll, earned-token debit, inventory grant, idempotency and tests. No UI or 3D model yet.

## 3 Case visuals
Read CS2-CASE-OPENING.md, CS2-3D-MODELS.md, CS2-MENU-UX.md. Build original 3D case + ViewportFrame presentation, reveal animation that stops on server-chosen result, odds UI and skip/reduced motion. Reuse backend; do not change probabilities.

## 4 Inventory
Read CS2-INVENTORY-SKINS.md and CS2-MENU-UX.md. Build inventory browser, inspect, equip and persisted ownership; tests for forged equip and rejoin.

## 5 Weapon
Read CS2-WEAPON-SYSTEM.md, CS2-ANIMATION.md, CS2-3D-MODELS.md. Upgrade only AK-style weapon viewmodel, detailed reload and third-person replication; do not add other weapons.

## 6 Sound and polish
Read CS2-SOUND-VFX.md and CS2-OPTIMIZATION.md. Add licensed/original SFX and pooled FX to one completed subsystem; profile and report actual metrics.

For every prompt: require changed file list, PASS/FAIL/NOT RUN, screenshots if available, and updated CS2-PROJECT-STATE.md. Do not repeat the whole skill pack in context.
