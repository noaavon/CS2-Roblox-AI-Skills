# Testing Skill
Run only tests relevant to changed subsystem plus smoke tests for regressions.

## Checklist
- Play Solo: no errors, assets load, camera/controls work.
- Two players: replication, team rules, damage, spectator and round transitions.
- Security: invalid RemoteEvent args, impossible fire rates, ammo underflow, spoofed hits, purchase abuse.
- Visual: viewmodel clipping, hand grip, UI scale, effects, animation blending.
- Performance: no unbounded loops/instances, effects cleanup, FPS and memory measurements when accessible.
- Network: test latency and packet loss where tools permit.

## Reporting
For every test state PASS / FAIL / NOT RUN, method and evidence. Never label NOT RUN as PASS. Fix blocking failures before unrelated work.
