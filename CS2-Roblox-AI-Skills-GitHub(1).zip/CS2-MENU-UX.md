# Complete menu and UI states
Screens: landing menu, Play, loadout, inventory, cases, case details, opening reel, reward showcase, item inspect, settings, HUD, buy menu, scoreboard, spectate, end-of-round. Original visual language with restrained dark panels, crisp typography, responsive layout, hover/focus states and keyboard navigation.

Case page: category tabs, preview of all possible items, transparent odds, earned-token balance, disabled button with explanation, confirm and result state. Reel supports skip and reduced motion. Inventory shows wear/pattern seed, rarity, equip and inspect; no fake marketplace price. HUD uses reusable design tokens.

Check 1280x720, 1920x1080 and 4:3, localization, UI overlap, focus trap, ESC behavior and accessibility.
