# Reusable low-token prompts
## Skill loader
Read CS2-PROJECT-RULES.md, CS2-PROJECT-STATE.md and only the single relevant skill file. Inspect existing Studio project and report affected paths. Implement one scoped feature, no unrelated changes. Run available tests and update CS2-PROJECT-STATE.md. Output concise changes, tests, blockers.
## Cases
Read CS2-CASE-OPENING.md, CS2-CASE-3D-PIPELINE.md, CS2-CASE-REEL-MOTION.md and visuals 01_CASE_SEQUENCE.svg, 05_UI_WIREFRAMES.svg. Implement case UI and server transaction separately, first a plan then code. No paid random items.
## Weapon animation
Read CS2-WEAPON-VIEWMODEL-RIG.md and CS2-KNIFE-ANIMATION-STORYBOARD.md plus visuals 02_VIEWMODEL_POSES.svg and 03_WEAPON_SILHOUETTES.svg. Implement only rig and one inspect sequence. Preserve existing combat logic.
## Skin preview
Read CS2-SKIN-MATERIAL-FACTORY.md and CS2-UI-SCREEN-SPECIFICATIONS.md. Implement 3D inspect preview for one original skin, then tests.
## Maps
Read CS2-MAP-ART-DIRECTION.md and 06_MAP_FLOW.svg. Greybox and validate route timing before adding detail.
