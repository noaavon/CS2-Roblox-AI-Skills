# Weapon, knife and case 3D modeling
Build original Roblox-styled high-quality meshes with readable silhouettes, bevels, proper smoothing, UVs and reasonable texture sizes. Assets: AK-inspired rifle, precision pistol, sniper, butterfly-style knife, curved knife, hard case, key, magazine, cartridge and shells. No ripped meshes.

For each asset document: reference silhouettes (not copied geometry), orthographic blockout, mesh component hierarchy, pivot points, attachment names (Muzzle, GripR, GripL, MagSocket, Eject), scale, materials, texture set, LOD, collision and triangle budget. Prefer Blender-authored FBX/glTF imports or Studio MeshParts. Never assert mesh is created if tooling unavailable.

Butterfly knife requires blade, handleA, handleB with separate hinge pivots; preserve safe animation constraints. Rifle needs detachable magazine and movable bolt, pistol slide, case lid with hinge. Deliver a preview screenshot, asset IDs, import instructions and an acceptance checklist. Avoid embedding unknown Toolbox scripts.
