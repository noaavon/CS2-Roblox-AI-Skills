# Server authority, currency and persistence
Separate round cash (competitive match) from cosmetic earned tokens (case opening). Never mix them accidentally. MVP has no Robux purchase, no paid keys, no cashout, no trading and no player-to-player transfer. Display all cosmetic odds and avoid manipulative urgency.

RemoteEvents carry requests only; server validates ownership, price, limits, state and rate limits. Use server RNG; idempotent transaction IDs; DataStore UpdateAsync with schema version, retry and reconciliation. Consider durable pending transactions to prevent lost rewards. Never trust client-supplied balances, rewards, odds, or hit reports. Log sanitized errors and never print secrets.

Test concurrent requests, replay, throttling, malformed types, disconnect, partial persistence, server restart and inventory consistency.
