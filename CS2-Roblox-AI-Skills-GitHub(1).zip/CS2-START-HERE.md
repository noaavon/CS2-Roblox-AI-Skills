# PROJECT CS2 SKILLS V3 — COMPLETE EDITION

This archive contains **AI instructions and original SVG schematic images**, not finished Roblox assets. It extends the V2 package without removing its 21 files. The original source archive was inspected.

## Quick start
1. Extract the whole folder next to your Roblox project.
2. Give Codex/Astra access to the extracted folder and Studio project.
3. Ask it to read `CS2-PROJECT-RULES.md`, `CS2-PROJECT-STATE.md`, and `CS2-IMPLEMENTATION-ROADMAP.md`.
4. Work on ONE milestone and ONE subsystem at a time. Use `CS2-CODEX-ASTRA-TASK-TEMPLATES.md` to minimize token usage.
5. Point the AI to the relevant `.svg` in `CS2-VISUAL-REFERENCES/` for original visual references. If the agent cannot read SVG, export PNG locally.
6. Verify in Studio before marking any step complete.

## Boundaries
All artwork is original schematic guidance. Do not reuse Valve game assets without authorization. No real-money or paid-random case mechanics. Keep reward generation on the server.
