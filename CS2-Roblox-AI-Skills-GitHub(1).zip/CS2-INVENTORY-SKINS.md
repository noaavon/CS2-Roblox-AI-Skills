# Inventory and cosmetic skins
Data model: itemInstanceId UUID, catalogId, skinId, wearTier, patternSeed, acquiredAt, equippedSlot, origin, schemaVersion. All owned inventory stored server-side. Cosmetic-only; never alter weapon damage or accuracy.

Implement catalog browsing, filter by type/rarity, search, sort, inspect 3D in ViewportFrame, equip per team/loadout, favorite, duplicate display, capacity pagination, safe DataStore retries and migration. Never allow client to supply arbitrary item ownership. Reconcile equipped item when deleted/unavailable. No player-to-player trading in MVP.

Original skins: procedural or authored UV/PBR palettes; 5 wear tiers with visual-only roughness/scratch overlays; pattern seed stable and deterministic. Design a unique rarity palette; avoid proprietary CS2 skins/logos. Test rejoin persistence, duplicates, simultaneous equip, invalid slot and low-end GPU.
