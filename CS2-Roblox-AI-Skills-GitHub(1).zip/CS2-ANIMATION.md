# Animation Skill
Scope: animation only unless user requests mechanics.

## Workflow
1. Identify rig (R15, custom arms/viewmodel) and joint hierarchy; do not break existing rigs.
2. List states: idle, equip, fire, recoil recovery, reload, inspect, walk, run, jump, land, crouch, switch, death where relevant.
3. Make original keyframe sequences inspired by observed motion, with anticipation, action, follow-through and recovery.
4. Coordinate hands, weapon, magazine and camera. Avoid hand penetration, weapon snapping and pose pops.
5. Set priorities and blend transitions. Use animation markers for sound, ammo commit, casing and magazine events.
6. Test at 30, 60 and 144 FPS if possible; timing must not depend on render frame rate.
7. Show exact assets/AnimationIds created and list any that still require publishing.

## Acceptance
No T-pose, no stuck tracks, no clipping in standard camera FOV, transitions work during sprint/reload/weapon switch.
